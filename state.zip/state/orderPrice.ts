import { atom } from "recoil";

export const orderPriceState = atom({
  key: "orderPriceState",
  default: 0,
});